const express = require('express');
const app = express();
const port = 8080;
app.get('/', function (req, res) {
    res.send('Hello World. Dzis');
});
app.listen(port, function () {
    console.log('Aplikacja nasłuchuje na porcie 8080!');
});

